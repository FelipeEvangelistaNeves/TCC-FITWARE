import React from "react";

const AlunoRoutes = () => {
  return <div>AlunRoutes</div>;
};

export default AlunoRoutes;
