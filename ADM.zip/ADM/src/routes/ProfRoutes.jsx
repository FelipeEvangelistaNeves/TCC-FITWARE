import React from "react";

const ProfRoutes = () => {
  return <div>ProfRoutes</div>;
};

export default ProfRoutes;
