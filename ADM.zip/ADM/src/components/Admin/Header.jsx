import React from "react";

export default function Header() {
  return (
    <header style={{ padding: "1rem", backgroundColor: "#f5f5f5" }}>
      <h1>Painel do Administrador</h1>
    </header>
  );
}
