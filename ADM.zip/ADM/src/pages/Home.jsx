import React from "react";
import Header from "../components/Hindex";
const Home = () => {
  return (
    <div>
      <Header></Header>
    </div>
  );
};

export default Home;
