import React from "react";

const LoginAluno = () => {
  return <div>LoginAluno</div>;
};

export default LoginAluno;
