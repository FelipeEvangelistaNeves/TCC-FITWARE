import React from "react";

const LoginProf = () => {
  return <div>LoginProf</div>;
};

export default LoginProf;
