export default function Financeiro() {
  return (
    <div className="admin-page">
      <h1>Financeiro</h1>
      <div className="finance-cards">
        <div className="card">Receita Total</div>
        <div className="card">Pendências</div>
        <div className="card">Pagamentos</div>
      </div>
    </div>
  );
}
