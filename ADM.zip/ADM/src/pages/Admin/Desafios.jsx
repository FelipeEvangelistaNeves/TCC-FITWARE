export default function Desafios() {
  return (
    <div className="admin-page">
      <h1>Desafios Ativos</h1>
      <div className="desafio-card">
        <h3>Desafio 30 Dias</h3>
        <p>Data de início: 01/08</p>
        <p>Participantes: 45</p>
      </div>
    </div>
  );
}
