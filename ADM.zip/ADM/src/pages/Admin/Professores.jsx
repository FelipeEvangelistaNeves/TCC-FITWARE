export default function Professores() {
  return (
    <div className="admin-page">
      <h1>Gerenciar Professores</h1>
      <ul>
        <li>Maria Souza - Treinos Funcionais</li>
        <li>Lucas Rocha - Musculação</li>
      </ul>
    </div>
  );
}
