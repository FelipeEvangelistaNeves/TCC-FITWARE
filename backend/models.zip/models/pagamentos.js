export const pagamentos = [
  {
    pa_id: 1,
    pa_aluno_id: 1,
    pa_valor: "129.99",
    pa_metodo: "P",
    pa_status: "Pendente",
    pa_data: "2025-08-11T03:00:00.000Z",
  },
  {
    pa_id: 2,
    pa_aluno_id: 2,
    pa_valor: "69.99",
    pa_metodo: "B",
    pa_status: "Pago",
    pa_data: "2025-09-11T03:00:00.000Z",
  },
];
