export const treinos_exercicios = [
  {
    tr_ex_id: 1,
    ex_tr_id: 1,
  },
  {
    tr_ex_id: 1,
    ex_tr_id: 2,
  },
  {
    tr_ex_id: 2,
    ex_tr_id: 3,
  },
  {
    tr_ex_id: 2,
    ex_tr_id: 4,
  },
];
