export const desafios = [
  {
    de_id: 1,
    de_nome: "Corrida de 500km",
    de_descricao: "Completar 500kms corridos em conjunto",
    de_pontos: 100,
    de_desafio: "corrida_500",
    de_progresso: 45,
    de_start: "2025-09-07T08:00:00.000Z",
    de_end: "2025-09-15T02:00:00.000Z",
  },
];
