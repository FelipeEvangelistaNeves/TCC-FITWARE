export const turmas = [
  {
    tu_id: 1,
    tu_nome: "Muay Thai",
    tu_prof_id: 4,
    tu_mod_id: 2,
    tu_hor_id: 2,
  },
  {
    tu_id: 2,
    tu_nome: "Alogamento",
    tu_prof_id: 3,
    tu_mod_id: 1,
    tu_hor_id: 1,
  },
];
