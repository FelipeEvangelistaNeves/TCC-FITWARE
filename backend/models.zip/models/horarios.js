export const horarios = [
  {
    hor_id: 1,
    hor_start: "08:00:00",
    hor_end: "09:00:00",
    hor_dia: "Segunda",
  },
  {
    hor_id: 2,
    hor_start: "23:00:00",
    hor_end: "00:00:00",
    hor_dia: "Sexta",
  },
];
