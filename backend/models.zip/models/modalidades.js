export const modalidades = [
  {
    mo_id: 1,
    mo_nome: "Flexibilidade",
    mo_descricao: "Treino focado em melhorar flexibilidade",
  },
  {
    mo_id: 2,
    mo_nome: "Luta",
    mo_descricao: "Treino de concentra‡Æo e disciplina",
  },
];
