export const treinos = [
  {
    tr_id: 1,
    tr_prof_id: 3,
    tr_nome: "Treino de Pernas",
    tr_descricao: "Série focada em quadríceps e glúteos",
    tr_repeticoes: "3x12",
  },
  {
    tr_id: 2,
    tr_prof_id: 4,
    tr_nome: "Treino de Peito",
    tr_descricao: "Série focada em peito e ombro",
    tr_repeticoes: "4x10",
  },
];
