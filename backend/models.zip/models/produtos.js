[
  {
    pd_id: 1,
    pd_nome: "Camiseta de Compressão",
    pd_valor: 800,
    pd_descricao: "Camiseta de compressão para treino",
  },
  {
    pd_id: 2,
    pd_nome: "Garrafa Stanley",
    pd_valor: 500,
    pd_descricao: "Garrafa de alumínio Stanley",
  },
];
