export const alunos_turmas = [
  {
    al_tu_id: 1,
    tu_al_id: 1,
  },
  {
    al_tu_id: 2,
    tu_al_id: 1,
  },
  {
    al_tu_id: 3,
    tu_al_id: 2,
  },
];
